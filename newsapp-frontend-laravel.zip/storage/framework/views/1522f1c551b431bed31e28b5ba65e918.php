
<?php $__env->startSection('title', "Register | Kawsar News Portal"); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="d-flex justify-content-center">
        <div>
            <h6 class="text-uppercase font-weight-bold mb-3">New Here, Register Here</h6>
            <form id="register_form" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <input id="name" type="text" class="form-control p-4" placeholder="Your name" />
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <input id="email" type="email" class="form-control p-4" placeholder="Your Email" />
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <input id="password" type="password" class="form-control p-4" placeholder="Password" />
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <input id="cpassword" type="password" class="form-control p-4" placeholder="Confirm Password" />
                            <div class="invalid-feedback"></div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-around">
                    
                    <input type="submit" class="btn btn-primary btn-block font-weight-semi-bold px-4" value="Register" id="register_btn">
                </div>
                <a class="my-3 text-secondary" href="<?php echo e(url('login')); ?>">Have an account? Login</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $("#register_form").submit(function(e) {
            e.preventDefault();
            $("#register_btn").val('Please wait...');
            $.ajax({
                url: "<?php echo e(route('register.post')); ?>",
                method: "POST",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    name: $("#name").val(),
                    email: $("#email").val(),
                    password: $("#password").val(),
                    cpassword: $("#cpassword").val(),
                },
                dataType: 'json',
                success: function(res){
                    if(res.status==400){
                        console.log(res.message)
                        console.log("aikhan theke")
                        
                        showError('name', res.message.name);
                        console.log("achi")
                        showError('email', res.message.email);
                        showError('password', res.message.password);
                        showError('cpassword', res.message.cpassword);
                        $("#register_btn").val('Register');
                    }
                    else if(res.status==200){
                        $("#register_form")[0].reset();
                        $("#register_btn").val('Register');
                        $("#show_success_alert").html(showMessage('success', res.messages));
                        removeValidationClasses("#register_form");
                        // window.location.href = "<?php echo e(route('login')); ?>";
                    }
                }
            })
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Projects\newsapp-frontend-laravel\resources\views/register.blade.php ENDPATH**/ ?>