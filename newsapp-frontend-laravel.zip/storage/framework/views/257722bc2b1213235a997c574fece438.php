<?php $__env->startSection('title', 'Login | Kawsar News Portal'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="d-flex justify-content-center">
            <div>
                <h6 class="text-uppercase font-weight-bold mb-3">Welcome Back, Login Here</h6>
                <form method="POST" id="login_form">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-md-12">
                            <div id="login_alert"></div>
                            <div class="form-group">
                                <input id="email" type="text" class="form-control p-4" placeholder="Your Email"
                                    required="required" />
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input id="password" type="password" class="form-control p-4" placeholder="Password"
                                    required="required" />
                                <div class="invalid-feedback"></div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex d-grid justify-content-around">
                        <button class="btn btn-primary btn-block font-weight-semi-bold px-4" style="height: 50px;"
                            type="submit" id="login_btn">Login</button>

                    </div>
                    <a class="my-3 text-secondary" href="<?php echo e(url('register')); ?>">New Here? Register</a>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        $(document).ready(function() {
        $("#login_form").submit(function(e) {
        e.preventDefault();
        $("#login_btn").val('Please wait...');
        $.ajax({
            url: "<?php echo e(route('login.post')); ?>",
            method: "POST",
            data: {
                email: $("#email").val(),
                password: $("#password").val(),
                _token: "<?php echo e(csrf_token()); ?>"
            },
            dataType: "json",
            success: function(response) {
                if (response.status==200) {
                    $("#login_btn").val('Login');
                    $("#login_form").trigger('reset');
                    $("#login_alert").html(showMessage('success', response.message));
                    setTimeout(function() {
                        window.location.href = "<?php echo e(url('profile')); ?>";
                    }, 2000);
                    
                }
                else if(response.status == 400){
                    showError('email', response.message.email);
                    showError('password', response.message.password);
                    $("#login_btn").val('Login');
                }
                 else {
                    $("#login_btn").val('Login');
                    $("#login_alert").html(showMessage('danger', response.message));
                }
            }
        });
        });
        });
        
        
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Projects\newsapp-frontend-laravel\resources\views/login.blade.php ENDPATH**/ ?>